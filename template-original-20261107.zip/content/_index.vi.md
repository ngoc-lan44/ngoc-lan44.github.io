---
title: "Báo cáo thực tập"
date: 2024-01-01
weight: 1
chapter: false
---

# Báo cáo thực tập

### Thông tin sinh viên:

&emsp; **Họ và tên:** Nguyễn Nhật Minh

&emsp; **Số điện thoại:** 0865404935

&emsp; **Email:** nhatminh6104@gmail.com

&emsp; **Trường:** Đại học Công nghệ TP.HCM (HUTECH University)

&emsp; **Ngành:** Công nghệ thông tin

&emsp; **Lớp:** 22DTHE8

&emsp; **Công ty thực tập:** Công ty TNHH Amazon Web Services Viet Nam

&emsp; **Vị trí thực tập:** Workforce Bootcamp - First Cloud AI Journey

&emsp; **Thời gian thực tập:** Từ ngày 17/04/2026 đến ngày 30/07/2026

![Ảnh đại diện — Nguyễn Nhật Minh](/images/avata.png?width=220px)

### Nội dung báo cáo

1.  [Worklog](1-Worklog/)
2.  [Proposal](2-Proposal/)
3.  [Các bài blogs đã đăng](3-BlogsPosted/)
4.  [Các events đã tham gia](4-EventParticipated/)
5.  [Workshop](5-Workshop/)
6.  [Tự đánh giá](6-Self-evaluation/)
7.  [Chia sẻ, đóng góp ý kiến](7-Feedback/)
